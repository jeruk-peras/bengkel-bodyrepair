<?php

namespace App\Models;

use CodeIgniter\Model;

class UnitModel extends Model
{
    protected $table            = 'unit';
    protected $primaryKey       = 'id_unit';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = false;
    protected $allowedFields    = [];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    // protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [
        'nama_sa'     => 'required|max_length[100]',
        'nomor_polisi'      => 'required|max_length[50]',
        'model_unit'        => 'required|max_length[100]',
        'warna_unit'        => 'required|max_length[100]',
        'asuransi_id'          => 'required|max_length[100]',
        'nomor_mesin'       => 'permit_empty|max_length[100]',
        'nomor_rangka'      => 'permit_empty|max_length[100]',
        'nomor_spp'         => 'required|max_length[100]',
        'tanggal_masuk'     => 'required|valid_date',
        'estimasi_selesai'  => 'required|valid_date',
        'detail_pengerjaan' => 'required',
        'harga_spp'         => 'required|numeric',
        'diskon'            => 'required|integer',
        'jumlah_diskon'     => 'required|numeric',
        'harga_panel'       => 'required|numeric',
        'jumlah_panel'      => 'required|numeric',
        'upah_mekanik'      => 'required|numeric',
        'total_upah_mekanik' => 'required|numeric',
        'status'            => 'required|integer',
        'color'            => 'permit_empty',
        'cabang_id'         => 'required|integer',
    ];
    protected $validationMessages   = [
        'nama_sa' => [
            'required'   => 'Nama so wajib diisi.',
            'max_length' => 'Nama so maksimal 100 karakter.',
        ],
        'nomor_polisi' => [
            'required'   => 'Nomor polisi wajib diisi.',
            'max_length' => 'Nomor polisi maksimal 50 karakter.',
        ],
        'model_unit' => [
            'required'   => 'Model unit wajib diisi.',
            'max_length' => 'Model unit maksimal 100 karakter.',
        ],
        'warna_unit' => [
            'required'   => 'Warna unit wajib diisi.',
            'max_length' => 'Warna unit maksimal 100 karakter.',
        ],
        'asuransi_id' => [
            'required'   => 'Asuransi wajib diisi.',
            'max_length' => 'Asuransi maksimal 100 karakter.',
        ],
        'nomor_mesin' => [
            'required'   => 'Nomor mesin wajib diisi.',
            'max_length' => 'Nomor mesin maksimal 100 karakter.',
        ],
        'nomor_rangka' => [
            'required'   => 'Nomor rangka wajib diisi.',
            'max_length' => 'Nomor rangka maksimal 100 karakter.',
        ],
        'nomor_spp' => [
            'required'   => 'Nomor SPP wajib diisi.',
            'max_length' => 'Nomor SPP maksimal 100 karakter.',
        ],
        'tanggal_masuk' => [
            'required'    => 'Tanggal masuk wajib diisi.',
            'valid_date'  => 'Tanggal masuk tidak valid.',
        ],
        'estimasi_selesai' => [
            'required'    => 'Estimasi selesai wajib diisi.',
            'valid_date'  => 'Estimasi selesai tidak valid.',
        ],
        'detail_pengerjaan' => [
            'required'   => 'Detail pengerjaan wajib diisi.',
        ],
        'harga_spp' => [
            'required'   => 'Harga SPP wajib diisi.',
            'numeric'    => 'Harga SPP harus berupa angka.',
        ],
        'diskon' => [
            'required'   => 'Diskon wajib diisi.',
            'integer'    => 'Diskon harus berupa angka bulat.',
        ],
        'jumlah_diskon' => [
            'required'   => 'Jumlah diskon wajib diisi.',
            'numeric'    => 'Jumlah diskon harus berupa angka.',
        ],
        'harga_panel' => [
            'required'   => 'Harga panel wajib diisi.',
            'numeric'    => 'Harga panel harus berupa angka.',
        ],
        'jumlah_panel' => [
            'required'   => 'Jumlah panel wajib diisi.',
            'numeric'    => 'Harga panel harus berupa angka.',
        ],
        'upah_mekanik' => [
            'required'   => 'Upah mekanik wajib diisi.',
            'numeric'    => 'Upah mekanik harus berupa angka.',
        ],
        'total_upah_mekanik' => [
            'required'   => 'Total upah mekanik wajib diisi.',
            'numeric'    => 'Total upah mekanik harus berupa angka.',
        ],
        'status' => [
            'required'   => 'Status wajib diisi.',
            'integer'    => 'Status harus berupa angka bulat.',
        ],
        'cabang_id' => [
            'required'   => 'Cabang wajib diisi.',
            'integer'    => 'Cabang harus berupa angka bulat.',
        ],
    ];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];
}
